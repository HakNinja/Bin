
#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
#define fn "f.dat"
void write_time(int h,int m,int s)
{
char str[20];
fstream file;
file.open(fn,ios::out|ios ::binary);
if(!file)
{
cout <<"error";
return;
}
cout<<"created";
sprintf(str,"%02d:%02d:%02d",h,m,s);
file.write(str,sizeof(str));
file.close();
}
void read_time(int *h,int *m,int *s)
{
char str[20];
int inh,inm,ins;
fstream file;
file.open(fn,ios::in|ios::binary);
if(!file)
{
cout <<"error";
return;
}
if (file.read((char*)str,sizeof(str)))
{
sscanf(str,"%02d:%02d:%02d",&inh,&inm,&ins);
*h=inh;
*h=inm;
*h=ins;
}
file.close();
}
int main()
{
	int m,h,s;
	cout<<"Enter time:";
	cout<<"h:";
	cin>>h;
	cout<<"m:";
	cin>>m;
	cout<<"s:";
	cin>>s;
	write_time(h,m,s);
	h=m=s=0;
	read_time(&h,&m,&s);
	cout<<"time is:";
	cout<<setw(2)<<setfill('0')<<h<<":";
	cout<<setw(2)<<setfill('0')<<m<<":";
	cout<<setw(2)<<setfill('0')<<s<<endl;
	return(0);
}